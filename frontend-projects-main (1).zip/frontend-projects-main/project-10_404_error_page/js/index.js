//For Go Back Button : (It's Optional You Can Also Use Anchor Tag Of Html)
let btn = document.getElementById("btn");
btn.addEventListener("click", () => {
  window.location.href="/"
});
